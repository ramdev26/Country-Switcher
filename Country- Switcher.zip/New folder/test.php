<?php
/**
 * Plugin Name: Country Switcher
 * Plugin URI: https://www.rameshgamage.me
 * Description: This is a WordPress plugin that adds a language and currency switcher to the header of a website. The switcher allows users to select a language and currency, and when a user clicks on a language/currency option, the plugin updates the language and currency options in the WordPress and WooCommerce settings.
 * Version: 1.0
 * Author: Ramesh Gamage
 * Author URI: https://www.rameshgamage.me
 **/

// Add the language switcher to the header
function add_language_switcher() {
  echo '<head>';
  echo '<meta charset="UTF-8">';
  echo '</head>';
  echo '<div class="language-switcher">';
  echo '<select onchange="location = this.value;">';
  echo '<option value="#">🇺🇸</option>';
  echo '<option value="?lang=usd">&#x1F1FA;&#x1F1F8;</option>'; // 🇺🇸
  echo '<option value="?lang=gbp">&#x1F1EC;&#x1F1E7;</option>'; // 🇬🇧
  echo '<option value="?lang=dkk">&#x1F1E9;&#x1F1F0;</option>'; // 🇩🇰
  echo '<option value="?lang=eur">&#x1F1E9;&#x1F1EA;</option>'; // 🇩🇪
  echo '<option value="?lang=ita">&#x1F1EE;&#x1F1F9;</option>'; // 🇮🇹
  echo '<option value="?lang=fra">&#x1F1EB;&#x1F1F7;</option>'; // 🇫🇷
  echo '<option value="?lang=nok">&#x1F1F3;&#x1F1F4;</option>'; // 🇳🇴
  echo '<option value="?lang=sek">&#x1F1F8;&#x1F1EA;</option>'; // 🇸🇪
  echo '</select>';
  echo '</div>';
}
add_action( 'wp_head', 'add_language_switcher' );

// Change the language and WooCommerce currency when a user clicks on the language switcher
function change_language_and_currency() {
  if ( isset( $_GET['lang'] ) ) {
    $lang = sanitize_text_field( $_GET['lang'] );
    switch ( $lang ) {
      case 'usd':
        $language = 'English US';
        $currency = 'USD';
        break;
      case 'gbp':
        $language = 'English UK';
        $currency = 'GBP';
        break;
      case 'dkk':
        $language = 'Danish';
        $currency = 'DKK';
        break;
      case 'eur':
        $language = 'Deutsch';
        $currency = 'EUR';
        break;
      case 'ita':
        $language = 'Italiano';
        $currency = 'EUR';
        break;
      case 'fra':
        $language = 'Français';
        $currency = 'EUR';
        break;
	  case 'nok':
        $language = 'Norwegian';
        $currency = 'NOK';
        break;
	  case 'sek':
        $language = 'Swedish';
        $currency = 'SEK';
        break;
      default:
        $language = 'English US';
        $currency = 'USD';
    }
    update_option( 'WPLANG', $language );
    update_option( 'woocommerce_currency', $currency );
  }
}
add_action( 'init', 'change_language_and_currency' );

// Update the currency rate
// Function to get the exchange rates from exchangeratesapi.io
function get_exchange_rates() {
  $api_key = '8GbwLcqtEAiKOqWk7VV3f92mM9JT61H7';
  $from_currency = get_option( 'woocommerce_currency' );
  $to_currency = 'USD';
  $curl = curl_init();

  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.apilayer.com/exchangerates_data/convert?to=".$to_currency."&from=".$from_currency."&amount=1",
    CURLOPT_HTTPHEADER => array(
      "Content-Type: text/plain",
      "apikey: " . $api_key
    ),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET"
  ));

  $response = curl_exec($curl);

  curl_close($curl);

  $data = json_decode($response, true);

  if(isset($data['result'])) {
    $exchange_rate = floatval($data['result']);
    update_option('wc_settings_tab_currency', array(
        'currency_pos' => 'right',
        'currency_symbol' => '$',
        'thousand_separator' => ',',
        'decimal_separator' => '.',
        'num_decimals' => 2,
        'format_num_decimals' => true,
        'exchange_rate' => $exchange_rate,
        'currency_updated' => time(),
        'default_currency' => $from_currency,
    ));
  }
}

// Update the currency rate
function update_currency_rate() {
  $wc_currency_updated = get_option('wc_settings_tab_currency')['currency_updated'];
  $current_time = time();
  $time_difference = ($current_time - $wc_currency_updated) / (60 * 60);

  if ($time_difference >= 24) {
    get_exchange_rates();
  }
}
add_action('wp_head', 'update_currency_rate');
